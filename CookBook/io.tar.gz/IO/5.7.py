# 读写压缩文件
import gzip
import bz2


# 你想读写一个gzip或bz2格式的压缩文件。
# gzip
with gzip.open('./1.gz', 'rt') as f:
    text = f.read()

# bz2
with bz2.open('./1.bz2', 'rt') as f:
    text = f.read()


